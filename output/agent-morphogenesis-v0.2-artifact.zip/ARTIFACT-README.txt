Agent Morphogenesis v0.2 companion artifact

This ZIP is an overlay, not the full AgentPlat repository or its dependencies.
Use an AgentPlat checkout at e978544915a329387e13883fa352191f6993dcc7 and
extract this overlay into that checkout. The original v0.1 files are not included
or overwritten. See docs/research/morphogenesis-paper-v0.2/README.md for commands.

The retained pilot has eleven prescribed cases using synthetic owners. It is
not a confirmatory utility benchmark or a production qualification. The
development-attempts directory preserves failed and intermediate attempts.

SHA256SUMS.json binds every overlaid file, including the PDF, figures, runner,
verifier, raw evidence and attempt history. These hashes detect changes; they
are not an authenticated signature or independent replication.

Rendering the PDF requires reportlab and the documented TTF fonts. Verifying
the retained evidence requires the built AgentPlat modules but no live services.
