Agent Morphogenesis v0.4 companion artifact

This ZIP is an overlay, not the full AgentPlat repository or its dependencies.
Use an AgentPlat checkout at e978544915a329387e13883fa352191f6993dcc7 and
extract this overlay into that checkout. The original v0.1 files are not included
or overwritten. See docs/research/morphogenesis-paper-v0.4/README.md for commands.

The retained boundary pilot has eleven prescribed cases using synthetic owners. It is
not a confirmatory utility benchmark or a production qualification. The
development-attempts directory preserves failed and intermediate attempts.
Version v0.3 also includes a separate local PostgreSQL Team/Work integration pilot.
Version v0.4 adds a frozen 1,536-run finite-grid comparison and its independent
exact-arithmetic/dependency oracle. It does not demonstrate LLM utility or
production performance. All three evidence classes remain distinct.

SHA256SUMS.json binds every overlaid file, including the PDF, figures, runner,
verifier, raw evidence and attempt history. These hashes detect changes; they
are not an authenticated signature or independent replication.

Rendering the PDF requires reportlab and the documented TTF fonts. Verifying
the retained evidence requires the built AgentPlat modules but no live services.
